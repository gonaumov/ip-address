<?php

/**********************************************************************
 * demo.megalan.php
 * Get all news from
 * http://www.megalan.bg/news.html
 * and construct xml structure.
 * @author: Georgi Naumov
 **********************************************************************/
 
error_reporting(E_ALL|E_STRICT); 
ini_set("display_errors", 1);
set_time_limit(0);

$newsUrl = "http://www.megalan.bg/news.html";
$newsElements = array();
$resultInfo = array();
$patternNews =  '#<div\s+class="news_title"\s*>([^<]+)</div>.+?<a\s+href="([^"]+)"#is';
$opts = array(
  'http' => array(
    'method'=> "GET",
    'header'=> array("Accept-language: en")
  )
); 
$context = stream_context_create($opts);
$response = file_get_contents($newsUrl, false, $context);

if(is_string($response) && strlen($response))
{
	if(preg_match_all($patternNews,$response,$newsElements))
	{
		$sizeOfnewsElements = count($newsElements[1]);
		for($i = 0 ; $i < $sizeOfnewsElements ; $i++)
		{
			$results = array();
			$currentTitle = strip_tags($newsElements[1][$i]);
			$currenLink = $newsElements[2][$i];
			$resultInfo[] = array('title' => $currentTitle,
			                      'link' => $currenLink); 
		}
	}
}


header('Content-Type: text/html; charset=windows-1251');
print "<pre>";
print_r($resultInfo);
print "</pre>";
?>