/****************************************************************
		 Handle project cookie 
		 @author: Georgi Naumov
*****************************************************************/
var _controls = [ "carnum","dd","mm", "jj","post", "code" ,"set" ,"price", "jaren"];

/*********************************************
 * Function for setting the
 * value of the control independently
 *  tag name. For input we will set value
 *  attribute, for div, span or other
 * innerHTML
 * @author Georgi Naumov 
 *********************************************/
function __setControlValue(aControl,aValue)
{
	var _tagName = typeof aControl.tagName == 'undefined' ? '' : aControl.tagName;
	var _htmlControls = new Array("SPAN","DIV");
	if($.inArray(_tagName, _htmlControls) == -1)
	{
		/**********************************************
		 * Setting value attribute of the control 
		 **********************************************/
		var _type = typeof $(aControl).attr("type") != 'undefined' ? $(aControl).attr("type") : "";
		$(aControl).attr("value",aValue);
		/*********************************
		 * Check radio button or
		 * checkbox
		 *********************************/
		if(_type == 'radio' || _type == 'checkbox')
		{
			$(aControl).attr("checked","checked");
			var _show_label  =  /(show_price[0-9]*)/.test($(aControl).attr("onclick")) ? RegExp.$1 : "";
			if(_show_label != "") {
				$("#"+_show_label).attr("class","displaybox");
			}
		}
	}
	else
	{
		/***********************************************
		 * Settign html of the control
		 * *********************************************/
		 var _ctrHtml = $(aControl).html();
		 _ctrHtml = _ctrHtml.replace(/[0-9.,]+/g,"");
		 _ctrHtml = _ctrHtml + " " + aValue;
		 $(aControl).html(_ctrHtml);
	}
}
function _saveinCookie(_a_url_to_go)
{
	$.each(_controls, function() 
	{
			$("[id^='"+this+"']").each(function (i) {
				
				var _type = typeof $(this).attr("type") != 'undefined' ? $(this).attr("type") : "";
				/*****************************************
				 * We will save only selected radiobutton
				 * and checkboxes ..
				 *****************************************/
				if(_type == 'radio' || _type == 'checkbox')
				{
					
					var _id = $(this).attr("id");
					if($(this).attr("checked"))
					{
						var _value = $(this).attr("value");
						$.cookie(_id,_value);
					}
					else
					{
						$.cookie(_id,null);
					}
				}
				else
				{
					var _id = $(this).attr("id");
					var _value = $(this).attr("value");
					$.cookie(_id,_value);
				}
			});
	});
	if(typeof _a_url_to_go != 'undefined')
	{
		window.location.href = _a_url_to_go;
	}
	return false;
}
function __update(){
	if(typeof UpdateCost ==  'function')
	{
			UpdateCost();
			UpdateCost1();
			UpdateCost3();
	}
}


function _readFromcookie()
{
	var _showed = false; 
	$.each(_controls, function() 
	{
			$("[id^='"+this+"']").each(function (i) {
				var _id = $(this).attr("id");
				var _cook = $.cookie(_id);
				if(_cook != null) 
				{
					if(/[0-9]$/.test(_id))
					{
						_showed = true;
					}
					__setControlValue(this,_cook);
					/*********************************
					 * Check radio button or
					 * checkbox
					 *********************************/
					var otherctr = "ext_"+_id;
					var _other = $("#"+otherctr);
					if(_other.length == 1)
					{
						_other.html(_cook);
					}
				}
				else
				{
					//__setControlValue(this,"0.00");
				}
			});
	});
	if(_showed)
	{
		$("[id^='show_a']").each(function(){
			var _id = $(this).attr("id");
			if(_id != "show_al")
			{
				$(this).attr("class",_id);
			}
		});
	}
}
function _get_url()
{
		var _url = /([a-z]+\.html$)/i.test(window.location.href) ? RegExp.$1 : "";
		return _url;
}
function _save_url()
{
		var _url = _get_url();
		$.cookie("old_url",_url);
}
/*****************************************************
	Emulating loged in
 *****************************************************/
function logedin(div_to_show)
{
	$.cookie("loggedid",div_to_show);
}

function wijzigen_clik()
{
		$.cookie("wijzigen",1);
}
/******************************************************
			Show the car 
*******************************************************/
function _showCar()
{
		if($("#carnum1").length == 1)
		{
				var _lengthToShow = 8;
				var _val = $("#carnum1").attr("value");
				var _re = /^[a-z0-9]{2}-[a-z0-9]{2}-[a-z0-9]{2}$/i;
				if(typeof _val != 'undefined' && _re.test(_val))
				{
						$("#show_cars").show("slow");
				}
		}
}
$(document).ready(function() {
		_readFromcookie();
		__update();
		_showCar();
		/******************************************
			Here we will check  if user is 
			go from order.htm.
		 ******************************************/
		 var _old_url = $.cookie("old_url");
		 if(_old_url != null && _old_url == "order.html")
		 {
			  if($("#div1").length == 1)
			  {
			 	 $("#div1").hide();
			  }
		 }
		 /****************************************************
		 	Opening div in order.html when user is logged
			and going from  calculation.html. 
		  ****************************************************/
		  var _url = _get_url();
		  var __logedin = $.cookie("loggedid");
		  if(_url == "order.html" && _old_url != null && _old_url == "calculation.html" && __logedin != null)
		  {
			  $("#"+__logedin).show("slow");
			  $("input[value='"+__logedin+"'][type='radio']").attr("checked","checked");
			  $.cookie("loggedid",null);
		  }
		  else
		  {
			  if($("input[value='DIV2'][type='radio']").length)
			  {
			  	$("input[value='DIV2'][type='radio']").attr("checked","checked");	  
			  }
		  }
		  var _wijzigen_clik = $.cookie("wijzigen");
		  if(_url == "calculation.html" && _wijzigen_clik != null)
		  {
			  $("#show_all_car,#beklik").hide();
			  $.cookie("wijzigen",null);
		  }
		  _save_url();
});