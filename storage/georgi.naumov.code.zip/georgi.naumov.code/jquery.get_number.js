/********************************************
	jQuery get_number plugin
	@author: Georgi Naumov
 ********************************************/
jQuery.fn.get_number = function() {
	var _number = /([0-9.]+)/.test(jQuery(this).html()) ? RegExp.$1 : 0;
	return parseFloat(_number);
};
