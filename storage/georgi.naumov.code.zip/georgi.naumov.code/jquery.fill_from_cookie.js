/********************************************************
	jQuery fill_from_cookie plugin
	@author: Georgi Naumov
	@example: 
		$("#totalcost").fill_from_cookie('set0-5');
	This will fill element with sum from 
	cookie from set0 to set5
 ********************************************************/
jQuery.fn.fill_from_cookie = function(range) {
	var _sum = 0;
	if(/([^0-9]+)([0-9]+)-([0-9]+)/.test(range))
	{
		var _name = RegExp.$1;
		var _start = parseInt(RegExp.$2);
		var _end = parseInt(RegExp.$3);
		_end += 1;
		for(var _i = _start; _i < _end; _i++)
		{
			var _cookName = _name+_i;
			var _cook = jQuery.cookie(_cookName);
			if(_cook != null)
			{
				_sum += parseFloat(_cook);
			}
		}
	}
	
	if(_sum != 0)
	{
		
		var _html = jQuery(this).html();
		_html = _html.replace(/[0-9.,]+/g,"");
		_html = _html + " " + _sum.toFixed(2);
		jQuery(this).html(_html);
	}
	else
	{
		var _html = jQuery(this).html();
		_html = _html.replace(/[0-9.,]+/g,"");
		jQuery(this).html(_html);
	}
};