/****************************************************************************
 *	After this you can directly check for valid email inside query.
 *	SELECT IF(is_valid_email('test@test.bg') = 1, some code , other code ) .. 
 *****************************************************************************/
CREATE FUNCTION is_valid_email(email varchar(255))
RETURNS INTEGER
NOT DETERMINISTIC
BEGIN
RETURN email REGEXP '^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}$';
END $$

